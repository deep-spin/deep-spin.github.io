import sys
for folder in sys.argv[1:]:
    mqm = float(open('%s/document_mqm' % folder).read().strip())
    nr_words = int(open('%s/total_words' % folder).read().strip())
    with open('%s/annotations.tsv' % folder) as fid:
        fid.readline()
        total_severity = 0
        for line in fid.readlines():
            severity_weight = line.strip().split('\t')[4]
            total_severity += float(severity_weight)
        hand_mqm = float("%3.6f" % (
            max(0., 100*(1 - total_severity * 1./nr_words))))
        assert mqm == hand_mqm
print("MQM matches annotations in %d documents" % len(sys.argv[1:]))
