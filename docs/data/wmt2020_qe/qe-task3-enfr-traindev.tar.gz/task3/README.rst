Each folder in the dataset corresponds to a document. Inside each one, there are
the following files:

* `source.segments`: the original source text, one sentence per line
* `source.tokenized`: a tokenized version of the above
* `mt.segments`: the original machine-translated text, one sentence per line
* `mt.tokenized`: the tokenized version of the above
* `annotations.tsv`: error annotations for the document. Each row corresponds
  to an error annotation, which in turn may contain one or more error spans.
  Fields are separated by tab and, in the case of a multi-span error, multiple
  starting positions and lengths are separated by whitespace. Note that these
  positions points to `mt.segments`, not tokenized.
* `token_annotations.tsv`: tokenized version of the above. Each error span that 
  contains one or more tokens has a "first token" and "last token". Again, 
  multi-span errors have their first and last tokens separated by whitespace.
  When a span is over a gap between two tokens, the "first" and "last" positions
  are `-`, and instead the `token_after_gap` column points to the token immediately
  after the gap. In case of a gap occurring at the end of the sentence, this 
  value will be equal to the number of tokens.
* `token_index`: a mapping of tokens to their start and ending positions in 
  `mt_segments`. For each token, a start and end value are separated by whitespace,
  and all tokens are separated by tabs.
* `total_words`: total number of words in the document

Notice that the output expected in the shared task is in the position-based
format of `annotations.tsv`, NOT the tokenized one. The file `token_index` may
help conversion from one to the other.
